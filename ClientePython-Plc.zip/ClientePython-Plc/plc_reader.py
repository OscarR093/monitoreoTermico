# plc_reader.py
import snap7
from snap7.util import get_real, get_bool
import time

class PLCReader:
    def __init__(self, ip, rack, slot, db_number, db_size):
        """
        Inicializa el lector de PLC.

        Args:
            ip (str): Dirección IP del PLC.
            rack (int): Número de rack del PLC.
            slot (int): Número de slot del PLC.
            db_number (int): Número del bloque de datos (DB) a leer.
            db_size (int): Tamaño en bytes del DB a leer.
        """
        self.ip = ip
        self.rack = rack
        self.slot = slot
        self.db_number = db_number
        self.db_size = db_size
        self.client = snap7.client.Client()
        self.is_connected = False
        self.reconnect_interval = 5  # Segundos para reintentar la conexión

    def connect(self):
        """Intenta establecer conexión con el PLC."""
        try:
            print(f"Intentando conectar al PLC en {self.ip}...")
            self.client.connect(self.ip, self.rack, self.slot)
            self.is_connected = True
            print("Conectado exitosamente al PLC.")
            return True
        except Exception as e:
            print(f"Fallo al conectar al PLC: {e}")
            self.is_connected = False
            return False

    def disconnect(self):
        """Cierra la conexión con el PLC si está abierta."""
        if self.is_connected:
            self.client.disconnect()
            self.is_connected = False
            print("Desconectado del PLC.")

    def read_temperatures(self):
        """
        Lee los datos de temperatura y estado de conexión desde el PLC.

        Retorna:
            list[dict] | None: Una lista de diccionarios con 'termopar', 'temperatura' y 'conectado',
                               o None si hay un error de lectura.
        """
        # Si no está conectado, intenta reconectar antes de leer
        if not self.is_connected:
            print("No conectado al PLC. Intentando reconectar...")
            if not self.connect():
                return None # No se pudo reconectar, retorna None

        try:
            data = self.client.db_read(self.db_number, 0, self.db_size)
            temperatures = []
            for i in range(8):
                temp_offset = i * 6  # REAL: 4 bytes, +2 bytes de espacio entre cada uno
                conn_offset = temp_offset + 4
                connected = get_bool(data, conn_offset, 0)

                if connected:
                    temp = get_real(data, temp_offset)
                    temperatures.append({'termopar': i + 1, 'temperatura': round(temp, 1), 'conectado': True})
                else:
                    temperatures.append({'termopar': i + 1, 'temperatura': None, 'conectado': False})
            return temperatures
        except Exception as e:
            print(f"Error al leer del PLC: {e}")
            self.is_connected = False # Marca como desconectado para forzar reconexión
            return None

    def ensure_connection(self):
        """Asegura que la conexión esté activa. Intenta conectar si no lo está."""
        if not self.is_connected:
            self.connect()

# Ejemplo de uso (para probar el módulo independientemente)
if __name__ == "__main__":
    PLC_IP = '192.168.0.1'  # Reemplaza con la IP de tu PLC
    RACK = 0
    SLOT = 1
    DB_NUMBER = 1
    DB_SIZE = 47

    reader = PLCReader(PLC_IP, RACK, SLOT, DB_NUMBER, DB_SIZE)
    reader.connect()

    try:
        while True:
            temps = reader.read_temperatures()
            if temps:
                print("\n=== Temperaturas Actuales ===")
                for t in temps:
                    if t['conectado']:
                        print(f"Termopar {t['termopar']}: {t['temperatura']} °C")
                    else:
                        print(f"⚠️ Termopar {t['termopar']} no conectado")
            else:
                print("No se pudieron recuperar las temperaturas.")
            time.sleep(reader.reconnect_interval) # Usa el intervalo de reconexión como ejemplo de espera
    except KeyboardInterrupt:
        print("\nSaliendo y desconectando...")
        reader.disconnect()